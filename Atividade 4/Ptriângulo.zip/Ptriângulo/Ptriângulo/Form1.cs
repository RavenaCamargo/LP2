﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriângulo
{
    public partial class Form1 : Form
    {
        double num1;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out num1))
                MessageBox.Show("Número inválido");
            if (txtNum1.Text == "")
                MessageBox.Show("Por favor inserir um número");
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out num1))
                MessageBox.Show("Número inválido");
            if (txtNum2.Text == "")
                MessageBox.Show("Por favor inserir um número");
        }

        private void txtNum3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum3.Text, out num1))
                MessageBox.Show("Número inválido");
            if (txtNum3.Text == "")
                MessageBox.Show("Por favor inserir um número");
        }

        private void btValidar_Click(object sender, EventArgs e)
        {
            double Lado1, Lado2, Lado3;

            Lado1 = Convert.ToDouble(txtNum1.Text);
            Lado2 = Convert.ToDouble(txtNum2.Text);
            Lado3 = Convert.ToDouble(txtNum3.Text);

            if (Lado1 == Lado2 && Lado1 == Lado3)
                lblResultado.Text = "Triângulo Equilátero";
            else
                if (Lado1 == Lado2 || Lado1 == Lado3 || Lado2 == Lado3)
                lblResultado.Text = "Triângulo Isósceles";
            else
                lblResultado.Text = "Triângulo Escaleno";
        }
    }
}
