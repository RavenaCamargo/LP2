﻿namespace PAtividade8_Oficial
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.lblProducao = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblGratificação = new System.Windows.Forms.Label();
            this.btnCalcSalBruto = new System.Windows.Forms.Button();
            this.cmbxCargo = new System.Windows.Forms.ComboBox();
            this.txtGratif = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(28, 37);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(55, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(151, 31);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(198, 26);
            this.txtNome.TabIndex = 1;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(28, 69);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(57, 20);
            this.lblCargo.TabIndex = 2;
            this.lblCargo.Text = "Cargo";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(151, 95);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(198, 26);
            this.txtMatricula.TabIndex = 5;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(28, 101);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(82, 20);
            this.lblMatricula.TabIndex = 4;
            this.lblMatricula.Text = "Matricula";
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(151, 127);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(198, 26);
            this.txtProducao.TabIndex = 7;
            // 
            // lblProducao
            // 
            this.lblProducao.AutoSize = true;
            this.lblProducao.Location = new System.Drawing.Point(28, 133);
            this.lblProducao.Name = "lblProducao";
            this.lblProducao.Size = new System.Drawing.Size(85, 20);
            this.lblProducao.TabIndex = 6;
            this.lblProducao.Text = "Produção";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(28, 165);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(65, 20);
            this.lblSalario.TabIndex = 8;
            this.lblSalario.Text = "Salário";
            // 
            // lblGratificação
            // 
            this.lblGratificação.AutoSize = true;
            this.lblGratificação.Location = new System.Drawing.Point(28, 197);
            this.lblGratificação.Name = "lblGratificação";
            this.lblGratificação.Size = new System.Drawing.Size(107, 20);
            this.lblGratificação.TabIndex = 10;
            this.lblGratificação.Text = "Gratificação";
            // 
            // btnCalcSalBruto
            // 
            this.btnCalcSalBruto.BackColor = System.Drawing.Color.Pink;
            this.btnCalcSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcSalBruto.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCalcSalBruto.Location = new System.Drawing.Point(80, 258);
            this.btnCalcSalBruto.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.btnCalcSalBruto.Name = "btnCalcSalBruto";
            this.btnCalcSalBruto.Size = new System.Drawing.Size(228, 109);
            this.btnCalcSalBruto.TabIndex = 12;
            this.btnCalcSalBruto.Text = "Calcular Salário bruto";
            this.btnCalcSalBruto.UseVisualStyleBackColor = false;
            this.btnCalcSalBruto.Click += new System.EventHandler(this.btnCalcSalBruto_Click);
            // 
            // cmbxCargo
            // 
            this.cmbxCargo.FormattingEnabled = true;
            this.cmbxCargo.Items.AddRange(new object[] {
            "Estagiário",
            "Operacional",
            "Gerente"});
            this.cmbxCargo.Location = new System.Drawing.Point(151, 63);
            this.cmbxCargo.Name = "cmbxCargo";
            this.cmbxCargo.Size = new System.Drawing.Size(198, 28);
            this.cmbxCargo.TabIndex = 13;
            // 
            // txtGratif
            // 
            this.txtGratif.Location = new System.Drawing.Point(151, 191);
            this.txtGratif.Name = "txtGratif";
            this.txtGratif.Size = new System.Drawing.Size(198, 26);
            this.txtGratif.TabIndex = 14;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(151, 159);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(198, 26);
            this.txtSalario.TabIndex = 14;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(428, 402);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtGratif);
            this.Controls.Add(this.cmbxCargo);
            this.Controls.Add(this.btnCalcSalBruto);
            this.Controls.Add(this.lblGratificação);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.lblProducao);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.Label lblProducao;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblGratificação;
        private System.Windows.Forms.Button btnCalcSalBruto;
        private System.Windows.Forms.ComboBox cmbxCargo;
        private System.Windows.Forms.TextBox txtGratif;
        private System.Windows.Forms.TextBox txtSalario;
    }
}