﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8_Oficial
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int numBrancos = 0;

            while (contador<rchtxtText.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtText.Text[contador]))
                    numBrancos += 1;

                contador++;
            }
            MessageBox.Show("Números de caracteres em branco: " + numBrancos);
        }

        private void btnLetR_Click(object sender, EventArgs e)
        {
            int qtdR = 0;

            foreach (char c in rchtxtText.Text) 
            {
                if (Char.ToUpper(c) == 'R')
                    qtdR += 1;
            }
                

            MessageBox.Show("A quantidade de letras R é: " + qtdR);
                    
        }

        private void btnLetRepetidas_Click(object sender, EventArgs e)
        {
            int letrasRep = 0;
            string auxiliar = rchtxtText.Text.Replace(" ", "");

            for (int i = 1; i < auxiliar.Length; i++)
            {
                if (auxiliar[i] == auxiliar[i-1])
                    letrasRep += 1;
            }

            MessageBox.Show("A quantidade de pares de letras repetidas é: " + letrasRep);
        }
    }
}
