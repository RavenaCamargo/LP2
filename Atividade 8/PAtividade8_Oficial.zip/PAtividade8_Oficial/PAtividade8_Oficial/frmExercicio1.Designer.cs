﻿namespace PAtividade8_Oficial
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtText = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBco = new System.Windows.Forms.Button();
            this.btnLetR = new System.Windows.Forms.Button();
            this.btnLetRepetidas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtText
            // 
            this.rchtxtText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtText.Location = new System.Drawing.Point(116, 24);
            this.rchtxtText.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rchtxtText.MaxLength = 100;
            this.rchtxtText.Name = "rchtxtText";
            this.rchtxtText.Size = new System.Drawing.Size(338, 208);
            this.rchtxtText.TabIndex = 0;
            this.rchtxtText.Text = "";
            // 
            // btnEspacoBco
            // 
            this.btnEspacoBco.BackColor = System.Drawing.Color.Pink;
            this.btnEspacoBco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspacoBco.Location = new System.Drawing.Point(38, 304);
            this.btnEspacoBco.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEspacoBco.Name = "btnEspacoBco";
            this.btnEspacoBco.Size = new System.Drawing.Size(137, 71);
            this.btnEspacoBco.TabIndex = 1;
            this.btnEspacoBco.Text = "Espaço em branco";
            this.btnEspacoBco.UseVisualStyleBackColor = false;
            this.btnEspacoBco.Click += new System.EventHandler(this.btnEspacoBco_Click);
            // 
            // btnLetR
            // 
            this.btnLetR.BackColor = System.Drawing.Color.Pink;
            this.btnLetR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetR.Location = new System.Drawing.Point(210, 304);
            this.btnLetR.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLetR.Name = "btnLetR";
            this.btnLetR.Size = new System.Drawing.Size(137, 71);
            this.btnLetR.TabIndex = 2;
            this.btnLetR.Text = "Letra R";
            this.btnLetR.UseVisualStyleBackColor = false;
            this.btnLetR.Click += new System.EventHandler(this.btnLetR_Click);
            // 
            // btnLetRepetidas
            // 
            this.btnLetRepetidas.BackColor = System.Drawing.Color.Pink;
            this.btnLetRepetidas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetRepetidas.Location = new System.Drawing.Point(382, 304);
            this.btnLetRepetidas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLetRepetidas.Name = "btnLetRepetidas";
            this.btnLetRepetidas.Size = new System.Drawing.Size(137, 71);
            this.btnLetRepetidas.TabIndex = 3;
            this.btnLetRepetidas.Text = "Letras repetidas";
            this.btnLetRepetidas.UseVisualStyleBackColor = false;
            this.btnLetRepetidas.Click += new System.EventHandler(this.btnLetRepetidas_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Plum;
            this.ClientSize = new System.Drawing.Size(561, 450);
            this.Controls.Add(this.btnLetRepetidas);
            this.Controls.Add(this.btnLetR);
            this.Controls.Add(this.btnEspacoBco);
            this.Controls.Add(this.rchtxtText);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtText;
        private System.Windows.Forms.Button btnEspacoBco;
        private System.Windows.Forms.Button btnLetR;
        private System.Windows.Forms.Button btnLetRepetidas;
    }
}