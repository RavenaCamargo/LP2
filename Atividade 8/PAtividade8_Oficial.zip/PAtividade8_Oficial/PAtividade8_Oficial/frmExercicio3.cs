﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8_Oficial
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnCkPalindromo_Click(object sender, EventArgs e)
        {
            string textoNormal = txtTexto.Text.Replace(" ", "");
            string textoInverso = txtTexto.Text.Replace(" ", "");
            txtTexto.CharacterCasing = CharacterCasing.Upper;
            int i;
            int lenght = textoNormal.Length;

            for (i = 0; i < lenght / 2; i++)
            {
                if (textoNormal[i] != textoInverso[lenght - i - 1])
                {
                    MessageBox.Show("O texto: " + txtTexto.Text + " não é palindromo");
                    break;
                }
                else
                {
                    MessageBox.Show("O texto: " + txtTexto.Text + " é palindromo");
                    break;
                }
            }
        }
    }
}
