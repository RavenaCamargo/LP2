﻿namespace PAtividade8_Oficial
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.btnCkPalindromo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(133, 68);
            this.txtTexto.Margin = new System.Windows.Forms.Padding(5);
            this.txtTexto.MaxLength = 50;
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(313, 26);
            this.txtTexto.TabIndex = 11;
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTexto.Location = new System.Drawing.Point(62, 74);
            this.lblTexto.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(58, 20);
            this.lblTexto.TabIndex = 10;
            this.lblTexto.Text = "Texto:";
            // 
            // btnCkPalindromo
            // 
            this.btnCkPalindromo.BackColor = System.Drawing.Color.Pink;
            this.btnCkPalindromo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCkPalindromo.Location = new System.Drawing.Point(66, 137);
            this.btnCkPalindromo.Margin = new System.Windows.Forms.Padding(12);
            this.btnCkPalindromo.Name = "btnCkPalindromo";
            this.btnCkPalindromo.Size = new System.Drawing.Size(380, 168);
            this.btnCkPalindromo.TabIndex = 9;
            this.btnCkPalindromo.Text = "Checar se é palindromo";
            this.btnCkPalindromo.UseVisualStyleBackColor = false;
            this.btnCkPalindromo.Click += new System.EventHandler(this.btnCkPalindromo_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(535, 344);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.btnCkPalindromo);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Button btnCkPalindromo;
    }
}