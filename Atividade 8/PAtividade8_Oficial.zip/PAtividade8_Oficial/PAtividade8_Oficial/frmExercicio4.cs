﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8_Oficial
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcSalBruto_Click(object sender, EventArgs e)
        {
            double A = 0, B = 0, C = 0, D = 0, salBruto = 0;
            double Gratificacao = int.Parse(txtGratif.Text);
            A = int.Parse(txtSalario.Text);
            double Producao;
            Producao = Convert.ToDouble(txtProducao.Text);

            if (int.Parse(txtProducao.Text) >= 100)
                B = 1;
            else if (int.Parse(txtProducao.Text) >= 120)
                C = 1;
            else if (int.Parse(txtProducao.Text) >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }
            else
            {
                B = 0;
                C = 0;
                D = 0;
            }

            salBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;

            if (salBruto <= 7000)
                MessageBox.Show("Seu salário bruto é: " + salBruto.ToString());
            else if (salBruto > 7000 && Producao >= 150)
                MessageBox.Show("Seu salário bruto é: " + salBruto.ToString());
            else if (salBruto > 7000 && Producao < 150)
                MessageBox.Show("Seu salário bruto não pode ser maior que 7000,00 se sua produção for inferior à 150");
        }
    }
}
