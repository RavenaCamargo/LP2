﻿namespace PAtividade8_Oficial
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGerarNum = new System.Windows.Forms.Button();
            this.lblNumInicial = new System.Windows.Forms.Label();
            this.txtNumInicial = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnGerarNum
            // 
            this.btnGerarNum.BackColor = System.Drawing.Color.Pink;
            this.btnGerarNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGerarNum.Location = new System.Drawing.Point(107, 121);
            this.btnGerarNum.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.btnGerarNum.Name = "btnGerarNum";
            this.btnGerarNum.Size = new System.Drawing.Size(228, 109);
            this.btnGerarNum.TabIndex = 5;
            this.btnGerarNum.Text = "Gerar número";
            this.btnGerarNum.UseVisualStyleBackColor = false;
            this.btnGerarNum.Click += new System.EventHandler(this.btnGerarNum_Click);
            // 
            // lblNumInicial
            // 
            this.lblNumInicial.AutoSize = true;
            this.lblNumInicial.Location = new System.Drawing.Point(52, 54);
            this.lblNumInicial.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNumInicial.Name = "lblNumInicial";
            this.lblNumInicial.Size = new System.Drawing.Size(126, 20);
            this.lblNumInicial.TabIndex = 6;
            this.lblNumInicial.Text = "Número inicial:";
            // 
            // txtNumInicial
            // 
            this.txtNumInicial.Location = new System.Drawing.Point(219, 53);
            this.txtNumInicial.Name = "txtNumInicial";
            this.txtNumInicial.Size = new System.Drawing.Size(180, 26);
            this.txtNumInicial.TabIndex = 8;
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(427, 275);
            this.Controls.Add(this.txtNumInicial);
            this.Controls.Add(this.lblNumInicial);
            this.Controls.Add(this.btnGerarNum);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGerarNum;
        private System.Windows.Forms.Label lblNumInicial;
        private System.Windows.Forms.TextBox txtNumInicial;

    }
}