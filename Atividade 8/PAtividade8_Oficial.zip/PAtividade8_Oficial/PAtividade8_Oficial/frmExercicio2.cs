﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8_Oficial
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerarNum_Click(object sender, EventArgs e)
        {
            int i;
            double Num1=0, Num2 = 0, x=2;

            if (txtNumInicial.Text == "0" || txtNumInicial.Text == null)
            {
                MessageBox.Show("Favor inserir um número maior que 0!");
                txtNumInicial.Focus();
            }
            else if (!double.TryParse(txtNumInicial.Text, out Num1) == true)
            {
                MessageBox.Show("Favor inserir um número!");
                txtNumInicial.Focus();
            }
            else 
                for(i=0;i<Num1;i++)
                {
                    Num2 += (1 / x);
                    x++;
                    if(x>Num2)
                        break;
                }
                MessageBox.Show("O número gerado é: " + Num2.ToString());
        }
    }
}
