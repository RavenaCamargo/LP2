﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerDesconto_Click(object sender, EventArgs e)
        {
            double salBruto, descontoINSS, descontoIRPF, salFamilia, salLiquido, numFilhos;


            salBruto = Convert.ToDouble(MskbxSalBruto.Text);
            numFilhos = Convert.ToDouble(CbxNumFilhos.Items);

            //calculo do INSS:
            if (salBruto <= 800.47)
            {
                txtAliqINSS.Text = "7.65%";
                descontoINSS = salBruto * 0.0765;
            }
            else
                if (salBruto >= 800.48 && salBruto <= 1050.00)
            {
                txtAliqINSS.Text = "8.65%";
                descontoINSS = salBruto * 0.0865;
            }
            else
                if (salBruto >= 1050.01 && salBruto <= 1400.77)
            {
                txtAliqINSS.Text = "9%";
                descontoINSS = salBruto * 0.09;
            }
            else
                if (salBruto >= 1400.78 && salBruto <= 2801.56)
            {
                txtAliqINSS.Text = "11%";
                descontoINSS = salBruto * 0.11;
            }
            else
            {
                txtAliqINSS.Text = "teto";
                descontoINSS = salBruto - 308.17;
            }

            //calculo do IRPF:

            if (salBruto <= 1257.12)
            {
                txtAliqIRPF.Text = "0";
                descontoIRPF = 0;
            }
            else
                if (salBruto >= 1257.13 && salBruto <= 2512.08)
            {
                txtAliqIRPF.Text = "15%";
                descontoIRPF = salBruto * 0.15;
            }
            else
            {
                txtAliqIRPF.Text = "27.5%";
                descontoIRPF = salBruto * 0.275;
            }

            //calculo do Salário familia:
            if (salBruto < 435.52)
                salFamilia = numFilhos * 22.33;
            else
                if (salBruto >= 435.53 && salBruto <= 654.61)
                salFamilia = numFilhos * 15.74;
            else
                salFamilia = 0;

            //calculo do Salário líquido:
            salLiquido = salBruto - descontoINSS - descontoIRPF + salFamilia;
            txtSalLiquido.Text = salLiquido.ToString();

            //mensagem do lblDados:
            if (rdCasado.Checked && rdFeminino.Checked)
                lblDados.Text = "Os descontos do salario da Sra." + (TxtNomeFunc) + "que é casada e que tem" + (CbxNumFilhos) + "filho(s) são:";
            else
                if (rdCasado.Checked && rdMasculino.Checked)
                lblDados.Text = "Os descontos do salario do Sr." + (TxtNomeFunc) + "que é casado e que tem" + (CbxNumFilhos) + "filho(s) são:";
            else
                if (!rdCasado.Checked && rdMasculino.Checked)
                lblDados.Text = "Os descontos do salario do Sr." + (TxtNomeFunc) + "que é solteiro e que tem" + (CbxNumFilhos) + "filho(s) são:";
            else
                if (!rdCasado.Checked && rdFeminino.Checked)
                lblDados.Text = "Os descontos do salario da Sra." + (TxtNomeFunc) + "que é solteira e que tem" + (CbxNumFilhos) + "filho(s) são:";
            else
                lblDados.Text = "Os descontos do salario do(a) Sr(a)." + (TxtNomeFunc) + "que tem" + (CbxNumFilhos) + "filho(s) são:";
        }

        private void TxtNomeFunc_Validated_1(object sender, EventArgs e)
        {
            char NomeFunc;

            if (char.TryParse(TxtNomeFunc.Text, out NomeFunc))
                MessageBox.Show("Nome inválido");
            else
                if (TxtNomeFunc.Text == "")
                MessageBox.Show("Por favor inserir um nome");
        }

        private void MskbxSalBruto_Validated_1(object sender, EventArgs e)
        {
            if (MskbxSalBruto.Text == "")
                MessageBox.Show("Por favor inserir seu salário");
        }

        private void CbxNumFilhos_Validated_1(object sender, EventArgs e)
        {
            if (CbxNumFilhos.Text == "")
                MessageBox.Show("Por favor informar a quantidade de filhos que possui");
        }

        private void CbxNumFilhos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CbxNumFilhos.SelectedIndex == -1)
                MessageBox.Show("Por favor informar a quantidade de filhos que possui");
        }
    }
}
