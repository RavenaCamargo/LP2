﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        char NomeFunc;
        double salBruto, numFilhos;

        //validações
        private void TxtNomeFunc_Validated_1(object sender, EventArgs e)
        {

            if (TxtNomeFunc.Text == "")
                MessageBox.Show("Por favor inserir um nome");
        }

        private void MskbxSalBruto_Validated_1(object sender, EventArgs e)
        {
            if (MskbxSalBruto.Text.Replace(",", "").Trim() == "")
                MessageBox.Show("Por favor inserir um salário");
            else
                if (!double.TryParse(MskbxSalBruto.Text, out salBruto))
                MessageBox.Show("Salário bruto deve ser número");
            else
                if (salBruto <= 0)
                MessageBox.Show("Salário bruto deve ser maior que 0");
        }

        private void CbxNumFilhos_Validated_1(object sender, EventArgs e)
        {
            if (CbxNumFilhos.Text == "")
                MessageBox.Show("Por favor informar a quantidade de filhos que possui");
            else
                if (!double.TryParse(CbxNumFilhos.Text, out numFilhos))
                MessageBox.Show("Número de filhos deve ser número");
        }

        private void CbxNumFilhos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CbxNumFilhos.SelectedIndex == -1)
                MessageBox.Show("Por favor informar a quantidade de filhos que possui");
        }


        private void Form1_Load_1(object sender, EventArgs e)
        {
            CbxNumFilhos.SelectedIndex = 0;
        }


        double descontoINSS, descontoIRPF, salFamilia, salLiquido;

        private void btnVerDesconto_Click(object sender, EventArgs e)
        {
            //calculo do IRPF:

            if (salBruto <= 1257.12)
            {
                txtAliqIRPF.Text = "0";
                txtDescIRPF.Text = "0";
            }
            else
                if (salBruto >= 1257.13 && salBruto <= 2512.08)
            {
                txtAliqIRPF.Text = "15%";
                descontoIRPF = salBruto * 0.15;
            }
            else
                if (salBruto > 2512.08)
            {
                txtAliqIRPF.Text = "27.5%";
                descontoIRPF = salBruto * 0.275;
            }

            txtDescIRPF.Text = descontoIRPF.ToString("N2");

            //calculo do INSS:
            if (salBruto <= 800.47)
            {
                txtAliqINSS.Text = "7.65%";
                descontoINSS = salBruto * 0.0765;
            }
            else
                if (salBruto >= 800.48 && salBruto <= 1050.00)
            {
                txtAliqINSS.Text = "8.65%";
                descontoINSS = salBruto * 0.0865;
            }
            else
                if (salBruto >= 1050.01 && salBruto <= 1400.77)
            {
                txtAliqINSS.Text = "9%";
                descontoINSS = salBruto * 0.09;
            }
            else
                if (salBruto >= 1400.78 && salBruto <= 2801.56)
            {
                txtAliqINSS.Text = "11%";
                descontoINSS = salBruto * 0.11;
            }
            else
                if (salBruto > 2801.56)
            {
                txtAliqINSS.Text = "teto";
                descontoINSS = 308.17;
            }

            txtDescINSS.Text = descontoINSS.ToString("N2");

            
            //calculo do Salário familia:
            if (salBruto < 435.52)
                salFamilia = numFilhos * 22.33;
            else
                if (salBruto >= 435.53 && salBruto <= 654.61)
                salFamilia = numFilhos * 15.74;
            else
                salFamilia = 0;

            txtSalFamilia.Text = salFamilia.ToString("N2");

            //calculo do Salário líquido:
            salLiquido = salBruto - descontoINSS - descontoIRPF + salFamilia;
            txtSalLiquido.Text = salLiquido.ToString();

            //mensagem do lblDados:
            if (ckbxCasado.Checked && rdFeminino.Checked)
                lblDados.Text = "Os descontos do salario da Sra." + " " + (TxtNomeFunc.Text) + " " + "que é casada e que tem" + " " + (CbxNumFilhos.Text) + " " + "filho(s) são:";
            else
                if (ckbxCasado.Checked && rdMasculino.Checked)
                lblDados.Text = "Os descontos do salario do Sr." + " " + (TxtNomeFunc.Text) + " " + "que é casado e que tem" + " " + (CbxNumFilhos.Text) + " " + "filho(s) são:";
            else
                if (!ckbxCasado.Checked && rdMasculino.Checked)
                lblDados.Text = "Os descontos do salario do Sr." + " " + (TxtNomeFunc.Text) + " " + "que é solteiro e que tem" + " " + (CbxNumFilhos.Text) + " " + "filho(s) são:";
            else
                if (!ckbxCasado.Checked && rdFeminino.Checked)
                lblDados.Text = "Os descontos do salario da Sra." + " " + (TxtNomeFunc.Text) + " " + "que é solteira e que tem" + " " + (CbxNumFilhos.Text) + " " + "filho(s) são:";
            else
                lblDados.Text = "Os descontos do salario do(a) Sr(a)." + " " + (TxtNomeFunc.Text) + " " + "que tem" + " " + (CbxNumFilhos.Text) + " " + "filho(s) são:";
        }
    }
}
