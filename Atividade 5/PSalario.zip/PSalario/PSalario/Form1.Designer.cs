﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.btnVerDesconto = new System.Windows.Forms.Button();
            this.TxtNomeFunc = new System.Windows.Forms.TextBox();
            this.MskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.CbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.grpbxSexo = new System.Windows.Forms.GroupBox();
            this.rdMasculino = new System.Windows.Forms.RadioButton();
            this.rdFeminino = new System.Windows.Forms.RadioButton();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.grpbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(33, 42);
            this.lblNomeFunc.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(203, 22);
            this.lblNomeFunc.TabIndex = 0;
            this.lblNomeFunc.Text = "Nome do funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(33, 79);
            this.lblSalBruto.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(130, 22);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salario bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(33, 121);
            this.lblNumFilhos.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(167, 22);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Numero de filhos";
            // 
            // btnVerDesconto
            // 
            this.btnVerDesconto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnVerDesconto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnVerDesconto.Location = new System.Drawing.Point(97, 162);
            this.btnVerDesconto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnVerDesconto.Name = "btnVerDesconto";
            this.btnVerDesconto.Size = new System.Drawing.Size(279, 34);
            this.btnVerDesconto.TabIndex = 3;
            this.btnVerDesconto.Text = "Verificar desconto";
            this.btnVerDesconto.UseVisualStyleBackColor = false;
            this.btnVerDesconto.Click += new System.EventHandler(this.btnVerDesconto_Click);
            // 
            // TxtNomeFunc
            // 
            this.TxtNomeFunc.Location = new System.Drawing.Point(254, 35);
            this.TxtNomeFunc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtNomeFunc.Name = "TxtNomeFunc";
            this.TxtNomeFunc.Size = new System.Drawing.Size(215, 29);
            this.TxtNomeFunc.TabIndex = 4;
            this.TxtNomeFunc.Validated += new System.EventHandler(this.TxtNomeFunc_Validated_1);
            // 
            // MskbxSalBruto
            // 
            this.MskbxSalBruto.Location = new System.Drawing.Point(253, 74);
            this.MskbxSalBruto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MskbxSalBruto.Mask = "00000.00";
            this.MskbxSalBruto.Name = "MskbxSalBruto";
            this.MskbxSalBruto.Size = new System.Drawing.Size(216, 29);
            this.MskbxSalBruto.TabIndex = 5;
            this.MskbxSalBruto.Validated += new System.EventHandler(this.MskbxSalBruto_Validated_1);
            // 
            // CbxNumFilhos
            // 
            this.CbxNumFilhos.DisplayMember = "1";
            this.CbxNumFilhos.FormattingEnabled = true;
            this.CbxNumFilhos.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10"});
            this.CbxNumFilhos.Location = new System.Drawing.Point(253, 112);
            this.CbxNumFilhos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.CbxNumFilhos.Name = "CbxNumFilhos";
            this.CbxNumFilhos.Size = new System.Drawing.Size(216, 30);
            this.CbxNumFilhos.TabIndex = 6;
            this.CbxNumFilhos.ValueMember = "1";
            this.CbxNumFilhos.SelectedIndexChanged += new System.EventHandler(this.CbxNumFilhos_SelectedIndexChanged);
            this.CbxNumFilhos.Validated += new System.EventHandler(this.CbxNumFilhos_Validated_1);
            // 
            // grpbxSexo
            // 
            this.grpbxSexo.Controls.Add(this.rdMasculino);
            this.grpbxSexo.Controls.Add(this.rdFeminino);
            this.grpbxSexo.Location = new System.Drawing.Point(628, 33);
            this.grpbxSexo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.grpbxSexo.Name = "grpbxSexo";
            this.grpbxSexo.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.grpbxSexo.Size = new System.Drawing.Size(216, 105);
            this.grpbxSexo.TabIndex = 7;
            this.grpbxSexo.TabStop = false;
            this.grpbxSexo.Text = "Sexo";
            // 
            // rdMasculino
            // 
            this.rdMasculino.AutoSize = true;
            this.rdMasculino.Location = new System.Drawing.Point(75, 70);
            this.rdMasculino.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdMasculino.Name = "rdMasculino";
            this.rdMasculino.Size = new System.Drawing.Size(45, 26);
            this.rdMasculino.TabIndex = 1;
            this.rdMasculino.Text = "M";
            this.rdMasculino.UseVisualStyleBackColor = true;
            // 
            // rdFeminino
            // 
            this.rdFeminino.AutoSize = true;
            this.rdFeminino.Checked = true;
            this.rdFeminino.Location = new System.Drawing.Point(75, 38);
            this.rdFeminino.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdFeminino.Name = "rdFeminino";
            this.rdFeminino.Size = new System.Drawing.Size(40, 26);
            this.rdFeminino.TabIndex = 0;
            this.rdFeminino.TabStop = true;
            this.rdFeminino.Text = "F";
            this.rdFeminino.UseVisualStyleBackColor = true;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(33, 225);
            this.lblDados.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(92, 22);
            this.lblDados.TabIndex = 9;
            this.lblDados.Text = "lblDados";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(33, 282);
            this.lblAliqINSS.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(135, 22);
            this.lblAliqINSS.TabIndex = 10;
            this.lblAliqINSS.Text = "Aliquota INSS";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Location = new System.Drawing.Point(33, 336);
            this.lblAliqIRPF.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(134, 22);
            this.lblAliqIRPF.TabIndex = 11;
            this.lblAliqIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(33, 385);
            this.lblSalFamilia.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(146, 22);
            this.lblSalFamilia.TabIndex = 12;
            this.lblSalFamilia.Text = "Salário Familia";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(33, 435);
            this.lblSalLiquido.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(150, 22);
            this.lblSalLiquido.TabIndex = 13;
            this.lblSalLiquido.Text = "Salario Liquido";
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(253, 276);
            this.txtAliqINSS.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(215, 29);
            this.txtAliqINSS.TabIndex = 14;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(254, 330);
            this.txtAliqIRPF.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(215, 29);
            this.txtAliqIRPF.TabIndex = 15;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(254, 379);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(215, 29);
            this.txtSalFamilia.TabIndex = 16;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(254, 429);
            this.txtSalLiquido.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(215, 29);
            this.txtSalLiquido.TabIndex = 17;
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(527, 276);
            this.lblDescINSS.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(148, 22);
            this.lblDescINSS.TabIndex = 18;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(528, 333);
            this.lblDescIRPF.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(147, 22);
            this.lblDescIRPF.TabIndex = 19;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(744, 271);
            this.txtDescINSS.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(215, 29);
            this.txtDescINSS.TabIndex = 20;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(744, 333);
            this.txtDescIRPF.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(215, 29);
            this.txtDescIRPF.TabIndex = 21;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(703, 184);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(100, 26);
            this.ckbxCasado.TabIndex = 22;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(989, 496);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.grpbxSexo);
            this.Controls.Add(this.CbxNumFilhos);
            this.Controls.Add(this.MskbxSalBruto);
            this.Controls.Add(this.TxtNomeFunc);
            this.Controls.Add(this.btnVerDesconto);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Form1";
            this.Text = "Folha de pagamento";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.grpbxSexo.ResumeLayout(false);
            this.grpbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Button btnVerDesconto;
        private System.Windows.Forms.TextBox TxtNomeFunc;
        private System.Windows.Forms.MaskedTextBox MskbxSalBruto;
        private System.Windows.Forms.ComboBox CbxNumFilhos;
        private System.Windows.Forms.GroupBox grpbxSexo;
        private System.Windows.Forms.RadioButton rdMasculino;
        private System.Windows.Forms.RadioButton rdFeminino;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.CheckBox ckbxCasado;
    }
}

