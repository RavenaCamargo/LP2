﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }





        private void btIMC_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;

            peso = Convert.ToDouble(maskPeso.Text);
            altura = Convert.ToDouble(maskAltura.Text);

            imc = peso / Math.Pow(altura, 2);

            if (imc < 18.5)
                lblResultado.Text = "Come mais feijão!\n" + Math.Round(imc,2);
            else
                if (imc>=18.5 && imc<24.9)
                    lblResultado.Text = "Normal\n" + Math.Round(imc, 2);
            else 
                if (imc>=25 && imc<29.9)
                    lblResultado.Text = "Fofinho(a)\n" + Math.Round(imc, 2);
            else
                if (imc>=30 && imc<39.9)
                    lblResultado.Text = "Melancia >.<\n" + Math.Round(imc, 2);
            else
                lblResultado.Text = "Cuidado! Obesidade grave\n" + Math.Round(imc, 2);
        }
    }
}
