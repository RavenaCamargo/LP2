﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAltura = new System.Windows.Forms.Label();
            this.maskAltura = new System.Windows.Forms.MaskedTextBox();
            this.maskPeso = new System.Windows.Forms.MaskedTextBox();
            this.btIMC = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblIMC = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltura.Location = new System.Drawing.Point(69, 39);
            this.lblAltura.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(54, 19);
            this.lblAltura.TabIndex = 0;
            this.lblAltura.Text = "Altura";
            // 
            // maskAltura
            // 
            this.maskAltura.Location = new System.Drawing.Point(137, 35);
            this.maskAltura.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.maskAltura.Mask = "0.00";
            this.maskAltura.Name = "maskAltura";
            this.maskAltura.Size = new System.Drawing.Size(173, 26);
            this.maskAltura.TabIndex = 2;
            // 
            // maskPeso
            // 
            this.maskPeso.Location = new System.Drawing.Point(137, 78);
            this.maskPeso.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.maskPeso.Mask = "000.00";
            this.maskPeso.Name = "maskPeso";
            this.maskPeso.Size = new System.Drawing.Size(173, 26);
            this.maskPeso.TabIndex = 3;
            // 
            // btIMC
            // 
            this.btIMC.BackColor = System.Drawing.Color.IndianRed;
            this.btIMC.Location = new System.Drawing.Point(84, 186);
            this.btIMC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btIMC.Name = "btIMC";
            this.btIMC.Size = new System.Drawing.Size(215, 83);
            this.btIMC.TabIndex = 4;
            this.btIMC.Text = "Calcular IMC";
            this.btIMC.UseVisualStyleBackColor = false;
            this.btIMC.Click += new System.EventHandler(this.btIMC_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(80, 82);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Peso";
            // 
            // lblIMC
            // 
            this.lblIMC.AutoSize = true;
            this.lblIMC.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIMC.Location = new System.Drawing.Point(85, 125);
            this.lblIMC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIMC.Name = "lblIMC";
            this.lblIMC.Size = new System.Drawing.Size(38, 19);
            this.lblIMC.TabIndex = 6;
            this.lblIMC.Text = "IMC";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(145, 126);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(16, 20);
            this.lblResultado.TabIndex = 7;
            this.lblResultado.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(389, 308);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblIMC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btIMC);
            this.Controls.Add(this.maskPeso);
            this.Controls.Add(this.maskAltura);
            this.Controls.Add(this.lblAltura);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Cálculo do IMC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.MaskedTextBox maskAltura;
        private System.Windows.Forms.MaskedTextBox maskPeso;
        private System.Windows.Forms.Button btIMC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblIMC;
        private System.Windows.Forms.Label lblResultado;
    }
}

