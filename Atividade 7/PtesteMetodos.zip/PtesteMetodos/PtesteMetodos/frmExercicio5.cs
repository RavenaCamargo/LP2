﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void brSorteio_Click(object sender, EventArgs e)
        {
            {
                Random numAleatorio = new Random();
                int Num1;
                int Num2;
                int Sorteio = 0;

                if (txtNumero1.Text == "" || txtNumero2.Text == "")
                    MessageBox.Show("Favor inserir um numero inicial e final!");
                else if (!int.TryParse(txtNumero1.Text, out Num1) == true)
                {
                    MessageBox.Show("Numero invalido!");
                    txtNumero1.Focus();
                }
                else if (!int.TryParse(txtNumero2.Text, out Num2) == true)
                {
                    MessageBox.Show("Numero invalido!");
                    txtNumero2.Focus();
                }
                else if (Num1 > Num2 || Num1 == Num2)
                    MessageBox.Show("O numero inicial deve ser diferente e menor que o numero final!");
                else
                    Sorteio = numAleatorio.Next(Num1, Num2);
                    MessageBox.Show("O numero sorteado entre " + txtNumero1.Text + " e " + txtNumero2.Text + " é: " + Sorteio.ToString());
            }
        }
    }
}
