﻿namespace PtesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btAlfa = new System.Windows.Forms.Button();
            this.btPosicao = new System.Windows.Forms.Button();
            this.btNum = new System.Windows.Forms.Button();
            this.rchtxt1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btAlfa
            // 
            this.btAlfa.BackColor = System.Drawing.Color.White;
            this.btAlfa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAlfa.Location = new System.Drawing.Point(302, 164);
            this.btAlfa.Name = "btAlfa";
            this.btAlfa.Size = new System.Drawing.Size(122, 69);
            this.btAlfa.TabIndex = 9;
            this.btAlfa.Text = "Alfabéticos";
            this.btAlfa.UseVisualStyleBackColor = false;
            this.btAlfa.Click += new System.EventHandler(this.btAlfa_Click);
            // 
            // btPosicao
            // 
            this.btPosicao.BackColor = System.Drawing.Color.White;
            this.btPosicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPosicao.Location = new System.Drawing.Point(146, 164);
            this.btPosicao.Name = "btPosicao";
            this.btPosicao.Size = new System.Drawing.Size(150, 69);
            this.btPosicao.TabIndex = 8;
            this.btPosicao.Text = "Posição Primeiro Espaço em Branco";
            this.btPosicao.UseVisualStyleBackColor = false;
            this.btPosicao.Click += new System.EventHandler(this.btPosicao_Click);
            // 
            // btNum
            // 
            this.btNum.BackColor = System.Drawing.Color.White;
            this.btNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum.Location = new System.Drawing.Point(12, 164);
            this.btNum.Name = "btNum";
            this.btNum.Size = new System.Drawing.Size(128, 69);
            this.btNum.TabIndex = 7;
            this.btNum.Text = "Numéricos";
            this.btNum.UseVisualStyleBackColor = false;
            this.btNum.Click += new System.EventHandler(this.btNum_Click);
            // 
            // rchtxt1
            // 
            this.rchtxt1.Location = new System.Drawing.Point(75, 30);
            this.rchtxt1.Name = "rchtxt1";
            this.rchtxt1.Size = new System.Drawing.Size(298, 84);
            this.rchtxt1.TabIndex = 10;
            this.rchtxt1.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(451, 313);
            this.Controls.Add(this.rchtxt1);
            this.Controls.Add(this.btAlfa);
            this.Controls.Add(this.btPosicao);
            this.Controls.Add(this.btNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btAlfa;
        private System.Windows.Forms.Button btPosicao;
        private System.Windows.Forms.Button btNum;
        private System.Windows.Forms.RichTextBox rchtxt1;
    }
}