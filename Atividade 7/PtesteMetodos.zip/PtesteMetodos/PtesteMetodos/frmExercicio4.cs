﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btNum_Click(object sender, EventArgs e)
        {
            int x = 0;
            for(int i = 0;i < rchtxt1.Text.Length; i++)
            {
                if (Char.IsNumber(rchtxt1.Text, i))
                    x += 1;          
            }
            MessageBox.Show("O texto < " + rchtxt1.Text + " > possui " + x.ToString() + " numeros");
        }

        private void btPosicao_Click(object sender, EventArgs e)
        {
            int i = 0;

            while (Char.IsWhiteSpace(rchtxt1.Text, i) == false)
                i++;

            MessageBox.Show("O texto > " + rchtxt1.Text + " < possui o primeiro caractere em branco na posição: " + i.ToString());
        }

        private void btAlfa_Click(object sender, EventArgs e)
        {
            int i = 0;


            foreach (char c in rchtxt1.Text)
            {
                if (Char.IsLetter(rchtxt1.Text, i))
                    i++;
            }

           MessageBox.Show("O texto < " + rchtxt1.Text + " > possui " + i.ToString() + " caracteres alfabéticos");

        }
    }
}
