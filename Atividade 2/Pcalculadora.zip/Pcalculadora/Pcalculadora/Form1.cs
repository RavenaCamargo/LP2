﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        double num1;

        private void Somar_Click(object sender, EventArgs e)
        {
            Result.Text = (float.Parse(textBox1.Text) + float.Parse(textBox2.Text)).ToString();
        }

        private void Subtrair_Click(object sender, EventArgs e)
        {
            Result.Text = (float.Parse(textBox1.Text) - float.Parse(textBox2.Text)).ToString();
        }

        private void Multiplicar_Click(object sender, EventArgs e)
        {
            Result.Text = (float.Parse(textBox1.Text) * float.Parse(textBox2.Text)).ToString();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox1.Text, out num1))
                MessageBox.Show("Número inválido");
            if (textBox1.Text == "")
                MessageBox.Show("Por favor inserir um número");
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox2.Text, out num1))
                MessageBox.Show("Número inválido");
            if (textBox2.Text == "")
                MessageBox.Show("Por favor inserir um número");
        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            Result.Text = "";
            textBox1.Focus();
        }

        private void Dividir_Validated(object sender, EventArgs e)
        {
            if (textBox2.Text == "0")
            {
                MessageBox.Show("Nao pode dividir por zero!");
                textBox2.Focus();
            }
            else
                Result.Text = (float.Parse(textBox1.Text) / float.Parse(textBox2.Text)).ToString();
        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
