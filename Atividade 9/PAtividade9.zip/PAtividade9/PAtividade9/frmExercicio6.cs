﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            string[] nome = new string[3];
            int[] qtdeCaracteres = new int[3];
            string[] removerEspacos = new string[3];
            string auxiliar;

            for (int i = 0; i < 3; i++)
            {
                auxiliar = Interaction.InputBox("Digite o " + (i + 1) + " nome: ");
                if (!char.IsLetter(auxiliar, i))
                {
                    MessageBox.Show("Nome inválido");
                    i--;
                }
                else
                {
                    foreach (char c in auxiliar)
                        nome[i] += c.ToString();
                }
                removerEspacos[i] = nome[i].Replace(" ", "");
                qtdeCaracteres[i] = removerEspacos[i].Length;
                ltbxNomes.Items.Add("O nome: " + nome[i].ToString() + " tem " + qtdeCaracteres[i].ToString() + " caracteres;");
            }
        }
    }
}
