﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PAtividade9
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            ArrayList list = new ArrayList();
            list.Add("Ana");
            list.Add("André");
            list.Add("Débora");
            list.Add("Fátima");
            list.Add("João");
            list.Add("Janete");
            list.Add("Otávio");
            list.Add("Marcelo");
            list.Add("Pedro");
            list.Add("Thais");

            int i;

            for (i = 0; i < list.Count; i++)
            {
                list.Remove("Otávio");
                MessageBox.Show(list[i].ToString());
            }

        }
    }
}
