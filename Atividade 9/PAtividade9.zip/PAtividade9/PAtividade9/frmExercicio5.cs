﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            //matriz bidimensional 20 alinos, 3 notas p cd aluno
            double[,] notas = new double[20,3];
            string auxiliar;
            double somarNotas = 0;
            double[] listaNotas = new double[20];
            int i, j; 

            for(i = 0; i < 20; i++)
            {
                for(j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a " + (j+1) + " nota do aluno " + (i+1) + ": ");
                    if (auxiliar == null)
                        break;
                    else if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Número inválido");
                        j--;
                    }
                    else if (notas[i, j] < 0 && notas[i, j] > 10)
                    {
                        MessageBox.Show("A nota deve ser entre 0 e 10!");
                        j--;
                    }
                    else
                        somarNotas = notas[i, j];     
                }
                listaNotas[i] = somarNotas * 3 / 3;
                somarNotas = 0;
                MessageBox.Show("A média do aluno " + (i + 1) + " é de: " + listaNotas[i].ToString());
            }
            
        }
    }
}
