﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }
        double faturaMensal;
        string auxiliar;
        int[] qtdMercadorias = new int[10];
        double[] precoUnit = new double[10];
        double[] total = new double[10];
        int i;

        private void btnExecute_Click(object sender, EventArgs e)
        {
            for (i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade das mercadorias vendidas do tipo " + (i + 1));
                if (!int.TryParse(auxiliar, out qtdMercadorias[i]))
                {
                    MessageBox.Show("Numero invalido!");
                    i--;
                }
                auxiliar = Interaction.InputBox("Digite o preço unitario das mercadorias tipo " + (i + 1));
                if (!double.TryParse(auxiliar, out precoUnit[i]))
                {
                    MessageBox.Show("Numero invalido!");
                    i--;
                }
                total[i] = qtdMercadorias[i] * precoUnit[i];
                faturaMensal += total[i];
             }
            MessageBox.Show("O faturamento mensal foi de: R$ " + faturaMensal.ToString());

        }
    }
}
